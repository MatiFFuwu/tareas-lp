Matías Fernández 202273506-6
El codigo se compone de 14 funciones, las cuales son llamadas entre sí y por el codigo principal ubicado al final del programa. 

Si se desea cambiar el archivo de prueba se debe acceder a la línea: 
**primeraLista = hacer_lista("problemas.txt")**, donde se debe cambiar el nombre del archivo al interior de los paréntesis.

Cualquier tipo de modificacion al código principal que involucre modificar el valor de la variable ANS debe ser hecho a conciencia, pues esta es una variable global.